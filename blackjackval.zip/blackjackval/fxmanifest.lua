fx_version "adamant"

game "rdr3"


this_is_a_map "yes"

rdr3_warning "I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships."

author "KingdomCarla"


dependency 'objectloader'

files {
    "blackjackval.xml",
     "stream/blackjack-val-2.ymap",

     
   }
   
   objectloader_maps {
     "blackjackval.xml",
   }